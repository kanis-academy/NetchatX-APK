# NetchatX — projet Android (Capacitor) prêt pour GitHub Actions

100 % Burkinabè 🇧🇫 · Créé par M. Simporé · `com.kanis.netchatx`

## Obtenir ton APK
1. Crée un dépôt GitHub (vide).
2. Envoie **tout le contenu de ce ZIP** à la racine du dépôt (y compris les dossiers cachés `.github` et le fichier `.gitignore`).
   - Avec Git : `git init && git add . && git commit -m "NetchatX" && git branch -M main && git remote add origin <URL> && git push -u origin main`
   - Avec le site GitHub : « Add file » → « Upload files », glisse **les dossiers** `.github`, `android`, `www` et les fichiers.
3. Onglet **Actions** → « Build NetchatX APK » → **Run workflow** (il démarre aussi tout seul à chaque envoi).
4. Quand la coche verte apparaît, ouvre l'exécution → section **Artifacts** → télécharge **NetchatX-APK** (ZIP contenant `NetchatX.apk`).
5. Sur le téléphone : ouvre `NetchatX.apk` et autorise l'installation depuis cette source.

## Contenu
- `www/` : le site NetchatX (index.html, manifest.webmanifest, sw.js, icons/) — inchangé.
- `android/` : projet Android (Gradle) généré pour Capacitor 6, nom **NetchatX**, identifiant **com.kanis.netchatx**.
- `capacitor.config.json`, `package.json` : configuration Capacitor.
- `.github/workflows/build.yml` : compile l'APK et le publie en Artifact.

## Remarques
- L'APK est signé avec la clé de débogage : il s'installe directement. Pour le Play Store il faudra une clé de signature personnelle (version « release »).
- Permissions déclarées (utilisées par l'app) : micro (vocaux), appareil photo, vibrations, réseau.
- Pour modifier le site, change les fichiers dans `www/` puis renvoie-les : l'APK se recompile.
