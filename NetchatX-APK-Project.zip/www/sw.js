const V="netchatx-v6",F=["./","./index.html","./manifest.webmanifest","./icons/icon-192.png","./icons/icon-512.png"];
self.addEventListener("install",e=>{e.waitUntil(caches.open(V).then(c=>c.addAll(F)));self.skipWaiting()});
self.addEventListener("activate",e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==V).map(x=>caches.delete(x)))));self.clients.claim()});
self.addEventListener("fetch",e=>{
  if(e.request.method!=="GET"||!e.request.url.startsWith("http"))return;
  e.respondWith(fetch(e.request).then(r=>{const c=r.clone();caches.open(V).then(k=>k.put(e.request,c)).catch(()=>{});return r})
    .catch(()=>caches.match(e.request).then(r=>r||caches.match("./index.html"))));
});
