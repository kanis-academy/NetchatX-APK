# Règles ProGuard (minification désactivée dans cette configuration).
# Voir http://developer.android.com/guide/developing/tools/proguard.html
