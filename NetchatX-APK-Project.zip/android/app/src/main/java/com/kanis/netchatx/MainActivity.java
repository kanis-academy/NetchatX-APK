package com.kanis.netchatx;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
